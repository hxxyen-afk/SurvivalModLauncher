package id.hxxyen.survivalmodlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.io.*;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private EditText urlInput;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(15, 45, 32));
        getWindow().setNavigationBarColor(Color.rgb(15, 45, 32));
        buildUi();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(12, 24, 19));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        TextView logo = new TextView(this);
        logo.setText("⚔  SURVIVAL");
        logo.setTextColor(Color.rgb(118, 235, 151));
        logo.setTextSize(14);
        logo.setLetterSpacing(0.16f);
        root.addView(logo);

        TextView title = new TextView(this);
        title.setText("MOD LAUNCHER");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(null, 1);
        title.setPadding(0, dp(8), 0, dp(4));
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Pengelola mod Minecraft • sederhana • offline");
        sub.setTextColor(Color.LTGRAY);
        sub.setTextSize(14);
        root.addView(sub);

        TextView note = new TextView(this);
        note.setText("Pilih file mod yang sudah ada di HP, atau unduh dari tautan saat internet tersedia. File akan disimpan di aplikasi lalu dibagikan ke Minecraft untuk diimpor.");
        note.setTextColor(Color.rgb(220, 230, 223));
        note.setTextSize(14);
        note.setLineSpacing(dp(3), 1f);
        note.setPadding(dp(14), dp(14), dp(14), dp(14));
        note.setBackgroundColor(Color.rgb(26, 47, 36));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(22);
        root.addView(note, np);

        addSection("1  •  IMPORT MOD DARI HP");
        addButton("Pilih file .mcpack / .mcaddon / .mcworld", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, 100);
        });

        addSection("2  •  UNDUH MOD (BUTUH INTERNET)");
        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setHint("https://situs/mod.mcpack");
        urlInput.setTextColor(Color.WHITE);
        urlInput.setHintTextColor(Color.GRAY);
        urlInput.setTextSize(14);
        urlInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        urlInput.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(118,235,151)));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = dp(8);
        root.addView(urlInput, ep);
        addButton("Unduh file mod", v -> downloadMod());

        addSection("3  •  MOD TERSIMPAN");
        addButton("Lihat / bagikan mod tersimpan", v -> showSavedMods());

        status = new TextView(this);
        status.setText("Status: siap. Impor mod memerlukan Minecraft Bedrock yang kompatibel.");
        status.setTextColor(Color.rgb(190, 207, 195));
        status.setTextSize(13);
        status.setPadding(0, dp(18), 0, dp(8));
        root.addView(status);

        TextView foot = new TextView(this);
        foot.setText("Catatan: aplikasi ini bukan launcher resmi dan tidak menyertakan Minecraft. Mod Java Edition tidak kompatibel dengan Bedrock.");
        foot.setTextColor(Color.GRAY);
        foot.setTextSize(12);
        foot.setPadding(0, dp(14), 0, 0);
        root.addView(foot);
    }

    private void addSection(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.rgb(118,235,151));
        t.setTextSize(13);
        t.setTypeface(null, 1);
        t.setPadding(0, dp(24), 0, dp(5));
        root.addView(t);
    }

    private void addButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Color.rgb(12, 24, 19));
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(118,235,151)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(8);
        root.addView(b, p);
        b.setOnClickListener(listener);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            shareUri(uri, guessMime(uri), "Pilih Minecraft untuk mengimpor file mod.");
        }
    }

    private String guessMime(Uri uri) {
        String name = uri.getLastPathSegment();
        if (name == null) name = "";
        name = name.toLowerCase(Locale.ROOT);
        if (name.endsWith(".mcpack")) return "application/octet-stream";
        if (name.endsWith(".mcaddon")) return "application/octet-stream";
        if (name.endsWith(".mcworld")) return "application/octet-stream";
        return "application/octet-stream";
    }

    private void downloadMod() {
        String link = urlInput.getText().toString().trim();
        if (!link.startsWith("https://")) {
            setStatus("Masukkan tautan HTTPS yang langsung menuju file mod.");
            return;
        }
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(urlInput.getWindowToken(), 0);
        setStatus("Mengunduh… pastikan tautan langsung menuju file .mcpack, .mcaddon, atau .mcworld.");
        executor.execute(() -> {
            try {
                URL url = new URL(link);
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "SurvivalModLauncher/1.0");
                int code = c.getResponseCode();
                if (code < 200 || code >= 300) throw new IOException("Server mengembalikan HTTP " + code);
                String path = url.getPath();
                String name = path.substring(path.lastIndexOf('/') + 1);
                if (!(name.toLowerCase(Locale.ROOT).endsWith(".mcpack") ||
                      name.toLowerCase(Locale.ROOT).endsWith(".mcaddon") ||
                      name.toLowerCase(Locale.ROOT).endsWith(".mcworld"))) {
                    throw new IOException("Tautan tidak tampak seperti file .mcpack, .mcaddon, atau .mcworld.");
                }
                name = name.replaceAll("[^A-Za-z0-9._-]", "_");
                File dir = new File(getFilesDir(), "mods");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Tidak bisa membuat folder mod.");
                File out = new File(dir, System.currentTimeMillis() + "_" + name);
                try (InputStream in = c.getInputStream(); FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] buf = new byte[8192]; int n; long total = 0;
                    while ((n = in.read(buf)) != -1) {
                        total += n;
                        if (total > 150L * 1024L * 1024L) throw new IOException("File lebih besar dari batas 150 MB.");
                        fos.write(buf, 0, n);
                    }
                } finally { c.disconnect(); }
                runOnUiThread(() -> {
                    setStatus("Unduhan selesai: " + out.getName());
                    shareFile(out);
                });
            } catch (Exception e) {
                runOnUiThread(() -> setStatus("Gagal mengunduh: " + e.getMessage()));
            }
        });
    }

    private void showSavedMods() {
        File dir = new File(getFilesDir(), "mods");
        File[] files = dir.listFiles();
        if (files == null || files.length == 0) {
            setStatus("Belum ada mod yang diunduh. Kamu bisa pilih file dari HP atau unduh lewat tautan.");
            return;
        }
        String[] names = new String[files.length];
        for (int i = 0; i < files.length; i++) names[i] = files[i].getName();
        new AlertDialog.Builder(this).setTitle("Mod tersimpan")
            .setItems(names, (dialog, which) -> shareFile(files[which]))
            .setNegativeButton("Tutup", null).show();
    }

    private void shareFile(File file) {
        try {
            Class<?> cls = Class.forName("androidx.core.content.FileProvider");
            Uri uri = (Uri) cls.getMethod("getUriForFile", Context.class, String.class, File.class)
                .invoke(null, this, getPackageName() + ".provider", file);
            shareUri(uri, "application/octet-stream", "Pilih Minecraft untuk mengimpor " + file.getName());
        } catch (Exception e) {
            setStatus("Tidak bisa membagikan file: " + e.getMessage());
        }
    }

    private void shareUri(Uri uri, String mime, String chooserTitle) {
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType(mime);
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, chooserTitle));
            setStatus("Pilih Minecraft jika tersedia. Jika tidak muncul, Minecraft mungkin tidak mendukung impor file ini di perangkatmu.");
        } catch (Exception e) {
            setStatus("Tidak ada aplikasi yang bisa menerima file ini.");
        }
    }

    private void setStatus(String s) {
        if (status != null) status.setText("Status: " + s);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}

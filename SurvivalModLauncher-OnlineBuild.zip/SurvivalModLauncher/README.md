# Survival Mod Launcher (Android)

Starter project for Android Studio. This is a lightweight Minecraft Bedrock mod importer/manager, not a Minecraft game or official launcher.

## Features
- Pick an existing `.mcpack`, `.mcaddon`, or `.mcworld` file using Android's document picker.
- Download direct HTTPS links to those file types when online.
- Keep downloaded files in app-private storage and share them with Minecraft for import.
- Manage and re-share downloaded files while offline.

## Build APK
1. Install Android Studio on a computer and install Android SDK Platform 35 (or let SDK Manager install it).
2. Open this project folder (`SurvivalModLauncher`) in Android Studio.
3. Allow Gradle sync to download Gradle and Android Gradle Plugin dependencies.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When finished, click **locate** in the notification. APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone, open it, and allow installation from that source if Android asks.

## Notes
- This source project has not been compiled in this environment because Android SDK/Gradle are not installed here.
- Downloading requires internet; importing and sharing already downloaded files can work offline.
- A direct file URL is required, not a webpage URL. Use trusted sources only.
- Minecraft Bedrock must be installed. Select Minecraft in the Android share sheet to import. Android/Minecraft versions may handle these files differently.
- Java Edition `.jar` mods are not compatible with Minecraft Bedrock.
- This app does not download Minecraft itself and is not affiliated with Mojang/Microsoft.


## Build APK online with GitHub Actions (no Android Studio needed)
1. Create a new repository on GitHub and upload the contents of this folder to the repository root.
2. Open the repository's **Actions** tab. If prompted, enable workflows.
3. Choose **Build Android APK** and press **Run workflow** (or push the files to the `main` branch).
4. When the run finishes successfully, open that run and download the **SurvivalModLauncher-APK** artifact.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open the APK on your Android phone to install it.

GitHub account and internet connection are required for the online build. This project has not been compiled or tested in this environment.
